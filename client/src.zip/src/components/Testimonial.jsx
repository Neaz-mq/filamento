import { useState } from "react";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { useLocaleLink } from "../i18n/useLocaleLink";
import "./Testimonial.css";

/* Figma "Frame 282" — বাঁয়ে বড় featured card (active testimonial),
   ডানে দুইটা ছোট card (পরের দুইটা)। arrow চাপলে সবকিছু এক ঘর করে
   ঘুরে যায় — ছোট card এ ক্লিক করলেও সেটা featured হয়ে যায়।

   ⚠️ নিচের quote/নাম/ছবি সবই placeholder — আসল client testimonial
   আর ছবি পেলে TESTIMONIALS array আর en/ja/zh-Hant.json এর
   "testimonials.items" অংশ বদলে দেবেন। ছবি না থাকলে initials
   দিয়ে avatar বানানো হচ্ছে (নিচে Avatar দেখুন), তাই ভাঙা <img>
   দেখানোর ঝুঁকি নেই। */
/* আসল client photo না আসা পর্যন্ত সবার জন্য একই ছবি — পরে যার যার
   real photo পেলে নিচের প্রতিটা entry তে আলাদা avatar বসিয়ে দেবেন,
   এই constant টা তখন আর লাগবে না */
const PLACEHOLDER_AVATAR =
  "https://res.cloudinary.com/dzi3u164c/image/upload/v1789637818/a73e9b59e7a15dc477a605d52bd4add7b91a67a9_pewd5s.jpg";

const TESTIMONIALS = [
  { id: "marcus", rating: 4.5, projectTo: "/projects/marcus-cold-storage", avatar: PLACEHOLDER_AVATAR },
  { id: "frank", rating: 4.0, projectTo: "/projects/frank-distribution-center", avatar: PLACEHOLDER_AVATAR },
  { id: "david", rating: 4.8, projectTo: "/projects/david-manufacturing-plant", avatar: PLACEHOLDER_AVATAR },
  { id: "elena", rating: 4.6, projectTo: "/projects/elena-warehouse-retrofit", avatar: PLACEHOLDER_AVATAR },
];

/* Figma: 18 x 23, Space Grotesk 500, underline — Contact.jsx এর
   ArrowIcon এর মতোই, শুধু diagonal (external/project link বোঝাতে) */
function ProjectIcon() {
  return (
    <svg
      width="12"
      height="12"
      viewBox="0 0 12 12"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
    >
      <path d="M4 8l4-4M4.5 4H8v3.5" />
    </svg>
  );
}

function ChevronIcon({ direction }) {
  return (
    <svg
      width="16"
      height="16"
      viewBox="0 0 16 16"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      style={{ transform: direction === "next" ? "rotate(180deg)" : undefined }}
    >
      <path d="M10 3 5 8l5 5" />
    </svg>
  );
}

/* ছবি না থাকলে নামের আদ্যক্ষর দিয়ে বৃত্ত বানায় — Figma তে সবার
   ছবি আছে, কিন্তু বাস্তব client photo হাতে না পাওয়া পর্যন্ত এটাই
   নিরাপদ fallback (ভাঙা img icon দেখাবে না) */
function Avatar({ name, src, className }) {
  const initials = name
    .split(" ")
    .map((part) => part[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();

  if (src) {
    return <img className={`testimonial-avatar ${className}`} src={src} alt="" />;
  }

  return (
    <div className={`testimonial-avatar testimonial-avatar-fallback ${className}`} aria-hidden="true">
      {initials}
    </div>
  );
}

/* fill: 0, 0.5, বা 1 — Figma র "Star 5" মাস্কড অর্ধেক তারার জন্য।
   পুরো তারাটা দুইবার আঁকা হয় (ধূসর ব্যাকগ্রাউন্ড + হলুদ overlay)।

   ⚠️ আগের ভার্সনে ভেতরের svg টা তার wrapper এর 100% width নিচ্ছিল —
   অর্ধেক তারার জন্য wrapper 50% width এ নামলে svg নিজেই সংকুচিত
   হয়ে ছোট হয়ে যাচ্ছিল (clip না হয়ে পুরো তারাটাই ছোট দেখাচ্ছিল,
   তাই 4.5 এর শেষ তারাটা খালি/ভাঙা দেখাচ্ছিল)। এখন ভেতরের svg কে
   সবসময় পুরো star-size এ fix করে overflow:hidden দিয়ে wrapper এর
   বাইরের অংশ কাটা হচ্ছে — svg নিজে আর ছোট হয় না, ঠিকঠাক clip হয় */
function Star({ fill }) {
  const path =
    "M10 1.2l2.47 5.13 5.53.8-4 4.04.94 5.63L10 14.14l-4.94 2.66.94-5.63-4-4.04 5.53-.8L10 1.2Z";

  return (
    <span className="testimonial-star">
      <svg className="testimonial-star-bg" viewBox="0 0 20 19" aria-hidden="true">
        <path d={path} fill="currentColor" />
      </svg>
      <span className="testimonial-star-fill" style={{ width: `${fill * 100}%` }}>
        <svg className="testimonial-star-fg" viewBox="0 0 20 19" aria-hidden="true">
          <path d={path} fill="currentColor" />
        </svg>
      </span>
    </span>
  );
}

function Stars({ value, size }) {
  // 4.5 কে সরাসরি ব্যবহার করা হয় — 4.3 এর মতো মান এলে নিকটতম 0.5 এ নামিয়ে আনা হয়
  const rounded = Math.round(value * 2) / 2;

  return (
    <span className="testimonial-stars" style={{ "--star-size": `${size}px` }}>
      {[0, 1, 2, 3, 4].map((index) => (
        <Star key={index} fill={Math.min(Math.max(rounded - index, 0), 1)} />
      ))}
    </span>
  );
}

function Rating({ value, size, t }) {
  return (
    <div className="testimonial-rating" role="img" aria-label={t("testimonials.ratingLabel", { value })}>
      <span className="testimonial-rating-value">{value.toFixed(1)}</span>
      <Stars value={value} size={size} />
    </div>
  );
}

/* ছোট দুইটা card এ Figma পাঁচটা তারা দেখায় না — সংখ্যার পাশে
   একটা মাত্র (সবসময় পুরো ভরা, সিদ্ধান্তমূলক নয়) star icon, শুধু
   accent হিসেবে। বড় featured card এর proportional 5-star Rating
   থেকে এটা তাই আলাদা component */
function MiniRating({ value, t }) {
  return (
    <div className="testimonial-rating" role="img" aria-label={t("testimonials.ratingLabel", { value })}>
      <span className="testimonial-rating-value">{value.toFixed(1)}</span>
      <span className="testimonial-mini-star" style={{ "--star-size": "24px" }}>
        <Star fill={1} />
      </span>
    </div>
  );
}

function ProjectLink({ to, label }) {
  const localeLink = useLocaleLink();

  return (
    <Link to={localeLink(to)} className="testimonial-project">
      <span>{label}</span>
      <span className="testimonial-project-icon">
        <ProjectIcon />
      </span>
    </Link>
  );
}

function Testimonial() {
  const { t } = useTranslation();
  const [activeIndex, setActiveIndex] = useState(0);

  const count = TESTIMONIALS.length;
  const at = (offset) => TESTIMONIALS[(activeIndex + offset + count) % count];

  const featured = at(0);
  const upcoming = [at(1), at(2)];

  const goPrev = () => setActiveIndex((current) => (current - 1 + count) % count);
  const goNext = () => setActiveIndex((current) => (current + 1) % count);

  const infoFor = (item) => ({
    quote: t(`testimonials.items.${item.id}.quote`),
    name: t(`testimonials.items.${item.id}.name`),
    role: t(`testimonials.items.${item.id}.role`),
  });

  const featuredInfo = infoFor(featured);

  return (
    <section id="testimonials" className="testimonials" aria-labelledby="testimonials-title">
      <div className="testimonials-inner">
        <div className="testimonials-head">
          <h2 id="testimonials-title" className="testimonials-title">
            {t("testimonials.title")}
          </h2>
          <p className="testimonials-text">{t("testimonials.text")}</p>
        </div>

        <div className="testimonials-row">
          {/* বড় card — Figma র "Group 65": পেছনে হালকা background layer,
              উপরে আসল content (দুটো আলাদা layer এখানে দরকার নেই,
              একটাতেই bg + content বসানো হয়েছে) */}
          <article className="testimonials-featured">
            <span className="testimonials-quote-mark" aria-hidden="true">
              &ldquo;
            </span>

            <Rating value={featured.rating} size={40} t={t} />

            <div className="testimonials-body">
              <p className="testimonial-quote">{featuredInfo.quote}</p>
              <hr className="testimonial-divider" />
              <div className="testimonial-person">
                <Avatar name={featuredInfo.name} src={featured.avatar} className="testimonial-avatar-lg" />
                <div className="testimonial-person-info">
                  <span className="testimonial-name">{featuredInfo.name}</span>
                  <span className="testimonial-role">{featuredInfo.role}</span>
                </div>
                <ProjectLink to={featured.projectTo} label={t("testimonials.project")} />
              </div>
            </div>
          </article>

          {/* ছোট দুইটা card — ক্লিক করলে সেটাই featured হয়ে যায়,
              তাই বোতাম হিসেবে বসানো (কীবোর্ডেও কাজ করে) */}
          <div className="testimonials-side">
            {upcoming.map((item) => {
              const info = infoFor(item);
              return (
                <button
                  key={item.id}
                  type="button"
                  className="testimonials-mini"
                  onClick={() => setActiveIndex(TESTIMONIALS.indexOf(item))}
                >
                  <Avatar name={info.name} src={item.avatar} className="testimonial-avatar-sm" />
                  <div className="testimonial-mini-info">
                    <span className="testimonial-name">{info.name}</span>
                    <span className="testimonial-role">{info.role}</span>
                  </div>
                  <MiniRating value={item.rating} t={t} />
                  <ProjectLink to={item.projectTo} label={t("testimonials.project")} />
                </button>
              );
            })}
          </div>

          {/* Figma তে arrow দুটো card গুলোর একদম কিনারায় ভেসে থাকে;
              মোবাইলে row একটা কলামে নেমে গেলে সেটা আর মানানসই না,
              তাই ছোট স্ক্রিনে এগুলো নিচে সাধারণ বোতাম হয়ে যায়
              (Testimonial.css এর responsive অংশ দেখুন) */}
          <div className="testimonials-nav">
            <button
              type="button"
              className="testimonials-arrow testimonials-arrow-prev"
              onClick={goPrev}
              aria-label={t("testimonials.prev")}
            >
              <ChevronIcon direction="prev" />
            </button>
            <button
              type="button"
              className="testimonials-arrow testimonials-arrow-next"
              onClick={goNext}
              aria-label={t("testimonials.next")}
            >
              <ChevronIcon direction="next" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Testimonial;