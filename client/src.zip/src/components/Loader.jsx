import { useEffect, useRef, useState } from "react";
import logoDark from "../assets/logo/logo-dark.png";
import logoRings from "../assets/logo/logo-rings.png";
import logoAccent from "../assets/logo/logo-accent.png";
import "./Loader.css";

const STAGE = {
  DARK: "dark",
  COLOR: "color",
  BAR: "bar",
  ROTATE: "rotate",
  FILL: "fill",
  FADE: "fade",
};

function Loader({ onRevealContent, onComplete }) {
  const [stage, setStage] = useState(STAGE.DARK);

  // callback গুলো ref-এ রাখছি যাতে parent re-render হলেও effect restart না হয়
  const callbacksRef = useRef({ onRevealContent, onComplete });
  useEffect(() => {
    callbacksRef.current = { onRevealContent, onComplete };
  }, [onRevealContent, onComplete]);

  useEffect(() => {
    const prefersReducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;

    if (prefersReducedMotion) {
      callbacksRef.current.onRevealContent?.();
      callbacksRef.current.onComplete?.();
      return;
    }

    document.body.style.overflow = "hidden";

    const timers = [
      setTimeout(() => setStage(STAGE.COLOR), 800),
      setTimeout(() => setStage(STAGE.BAR), 1500),
      setTimeout(() => setStage(STAGE.ROTATE), 1950),
      setTimeout(() => setStage(STAGE.FILL), 2500),
      setTimeout(() => {
        callbacksRef.current.onRevealContent?.();
        setStage(STAGE.FADE);
      }, 3300),
      setTimeout(() => {
        document.body.style.overflow = "";
        callbacksRef.current.onComplete?.();
      }, 3750),
    ];

    return () => {
      timers.forEach(clearTimeout);
      document.body.style.overflow = "";
    };
  }, []); // খালি dependency — mount এ একবারই setup, StrictMode নিজে থেকেই handle করবে

  return (
    <div className={`loader loader--${stage}`} aria-hidden="true">
      <div className="loader-mark">
        <img src={logoDark} alt="" className="loader-logo-img loader-logo-img--dark" />
        <img src={logoRings} alt="" className="loader-logo-img loader-logo-img--rings" />
        <img src={logoAccent} alt="" className="loader-accent" />
        <div className="loader-fill-bar" />
      </div>
    </div>
  );
}

export default Loader;