import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { useLocaleLink } from "../i18n/useLocaleLink";
import "./Projects.css";

/* ===============================================================
   PROJECTS — লিস্ট পাতা

   Figma নকশা: ধূসর card এর ভেতরে সার্চ বার + "All environments"
   dropdown, তার নিচে category pill এর সারি (আনুভূমিক scroll),
   তারপর project card এর grid, সবশেষে pagination.

   ⚠️ backend/CMS এখনো নেই — তাই PROJECTS array এ হাতে বসানো ডেটা।
   admin থেকে project যোগ/বাদ দেওয়া চালু হলে এই array টা বাদ দিয়ে
   API থেকে আনলেই বাকি সব (search, filter, pagination) এমনিই কাজ
   করবে — নিচের UI কোড ডেটার উৎস নিয়ে মাথা ঘামায় না।

   ⚠️ ছবি: Unsplash এর সরাসরি photo link এই container থেকে যাচাই
   করার উপায় ছিল না (API key ছাড়া, আর image-search টুল থেকে
   embed করার মতো URL পাওয়া যায় না) — তাই আপাতত Picsum (picsum.photos)
   থেকে বাস্তব ছবি বসানো হয়েছে, প্রতিটা প্রজেক্টের seed অনুযায়ী
   নির্দিষ্ট (তাই বারবার একই ছবি দেখাবে, পাতা reload করলেও বদলাবে
   না)। আসল project photography বা নির্দিষ্ট Unsplash pick হাতে
   পেলে নিচের PROJECTS array এর image ফিল্ডটা শুধু বদলে দিলেই হবে।
   =============================================================== */

const PAGE_SIZE = 4;

const picsum = (seed, w = 720, h = 900) =>
  `https://picsum.photos/seed/${seed}/${w}/${h}`;

/* category — projects.categories.<key> এর সাথে মেলে, আর Footer.jsx
   এর COLUMNS["projects"].links এর সাথেও (?category=xxx) মিলিয়ে
   রাখা, যাতে footer এর link থেকে সরাসরি সঠিক filter এ আসে */
const PROJECTS = [
  {
    slug: "denver-regional-airport",
    name: "Denver Regional Airport",
    city: "Denver, Colorado",
    category: "airport",
    image: picsum("denver-regional-airport"),
  },
  {
    slug: "barn-xo",
    name: "Barn XO",
    city: "Chicago, Illinois",
    category: "retail",
    image: picsum("barn-xo"),
  },
  {
    slug: "westside-auto-gallery",
    name: "Westside Auto Gallery",
    city: "Austin, Texas",
    category: "automotiveDealership",
    image: picsum("westside-auto-gallery"),
  },
  {
    slug: "precision-auto-works",
    name: "Precision Auto Works",
    city: "Miami, Florida",
    category: "automotiveDealership",
    image: picsum("precision-auto-works"),
  },
  {
    slug: "grace-community-church",
    name: "Grace Community Church",
    city: "Nashville, Tennessee",
    category: "church",
    image: picsum("grace-community-church"),
  },
  {
    slug: "st-andrews-cathedral",
    name: "St. Andrew's Cathedral",
    city: "Boston, Massachusetts",
    category: "church",
    image: picsum("st-andrews-cathedral"),
  },
  {
    slug: "lakeside-convention-center",
    name: "Lakeside Convention Center",
    city: "Cleveland, Ohio",
    category: "conventionCenter",
    image: picsum("lakeside-convention-center"),
  },
  {
    slug: "central-high-gymnasium",
    name: "Central High Gymnasium",
    city: "Columbus, Ohio",
    category: "gymnasium",
    image: picsum("central-high-gymnasium"),
  },
  {
    // Testimonial.jsx এর "David R." এর quote এই প্রজেক্টের কথাই বলছে
    slug: "david-manufacturing-plant",
    name: "David's Manufacturing Plant",
    city: "Detroit, Michigan",
    category: "manufacturing",
    image: picsum("david-manufacturing-plant"),
  },
  {
    slug: "harborview-office-park",
    name: "Harborview Office Park",
    city: "Seattle, Washington",
    category: "office",
    image: picsum("harborview-office-park"),
  },
  {
    slug: "meridian-tech-campus",
    name: "Meridian Tech Campus",
    city: "San Jose, California",
    category: "office",
    image: picsum("meridian-tech-campus"),
  },
  {
    slug: "union-square-retail-center",
    name: "Union Square Retail Center",
    city: "San Francisco, California",
    category: "retail",
    image: picsum("union-square-retail-center"),
  },
  {
    // Testimonial.jsx এর "Elena M." এর quote
    slug: "elena-warehouse-retrofit",
    name: "Elena's Warehouse Retrofit",
    city: "Phoenix, Arizona",
    category: "warehouse",
    image: picsum("elena-warehouse-retrofit"),
  },
  {
    slug: "riverside-conference-center",
    name: "Riverside Conference Center",
    city: "Portland, Oregon",
    category: "conferenceCenter",
    image: picsum("riverside-conference-center"),
  },
  {
    slug: "downtown-street-lighting-upgrade",
    name: "Downtown Street Lighting Upgrade",
    city: "Sacramento, California",
    category: "streetLights",
    image: picsum("downtown-street-lighting-upgrade"),
  },
  {
    // Testimonial.jsx এর "Marcus L." এর quote
    slug: "marcus-cold-storage",
    name: "Marcus Cold Storage Facility",
    city: "Minneapolis, Minnesota",
    category: "coldStorage",
    image: picsum("marcus-cold-storage"),
  },
  {
    // Testimonial.jsx এর "Frank S." এর quote
    slug: "frank-distribution-center",
    name: "Frank's Distribution Center",
    city: "Dallas, Texas",
    category: "distributionCenter",
    image: picsum("frank-distribution-center"),
  },
  {
    slug: "riverfront-manufacturing-annex",
    name: "Riverfront Manufacturing Annex",
    city: "Pittsburgh, Pennsylvania",
    category: "manufacturing",
    image: picsum("riverfront-manufacturing-annex"),
  },
];

/* pill এর ক্রম — screenshot এর মতোই, "All Projects" সবার আগে */
const CATEGORY_ORDER = [
  "all",
  "airport",
  "automotiveDealership",
  "church",
  "conventionCenter",
  "gymnasium",
  "manufacturing",
  "office",
  "retail",
  "warehouse",
  "conferenceCenter",
  "coldStorage",
  "distributionCenter",
  "streetLights",
];

function SearchIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <circle cx="9" cy="9" r="6.5" stroke="#40464E" strokeWidth="1.6" />
      <path d="M17 17l-3.6-3.6" stroke="#40464E" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}

function ChevronDown() {
  return (
    <svg width="10" height="6" viewBox="0 0 10 6" fill="none" aria-hidden="true">
      <path d="M1 1l4 4 4-4" stroke="#373A3C" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function PinIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <path
        d="M8 14.5S13 10 13 6.5A5 5 0 0 0 3 6.5C3 10 8 14.5 8 14.5Z"
        stroke="currentColor"
        strokeWidth="1.4"
      />
      <circle cx="8" cy="6.5" r="1.8" stroke="currentColor" strokeWidth="1.4" />
    </svg>
  );
}

function ArrowUpRight() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
      <path d="M5.5 12.5 12.5 5.5" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
      <path
        d="M6.8 5.5H12.5V11.2"
        stroke="#fff"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function ChevronArrow({ direction = "left" }) {
  return (
    <svg
      width="8"
      height="14"
      viewBox="0 0 8 14"
      fill="none"
      aria-hidden="true"
      style={{ transform: direction === "right" ? "rotate(180deg)" : undefined }}
    >
      <path d="M7 1 1 7l6 6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/* ট্যাবের শিরোনাম — ComingSoon.jsx এর মতোই প্যাটার্ন, খালি
   দরকার নেই noindex — পাতা তো এখন সত্যিই আছে */
function usePageMeta(title) {
  useEffect(() => {
    const previousTitle = document.title;
    document.title = `${title} | Filamento`;
    return () => {
      document.title = previousTitle;
    };
  }, [title]);
}

/* pill এর সারি — নিজের প্রস্থের চেয়ে বেশি হলে আনুভূমিক scroll,
   দুইপাশে তীরচিহ্ন। মাউস/touch দিয়ে সোয়াইপ করাও যায় (overflow-x),
   তীরগুলো শুধু সুবিধার জন্য */
function CategoryRow({ tabsRef, onScroll, canLeft, canRight, onLeft, onRight, children }) {
  return (
    <div className="projects-tabs-wrap">
      {canLeft && (
        <button
          type="button"
          className="projects-tabs-arrow is-left"
          onClick={onLeft}
          aria-label="Scroll categories left"
        >
          <ChevronArrow direction="left" />
        </button>
      )}
      <div className="projects-tabs" ref={tabsRef} onScroll={onScroll} role="tablist">
        {children}
      </div>
      {canRight && (
        <button
          type="button"
          className="projects-tabs-arrow is-right"
          onClick={onRight}
          aria-label="Scroll categories right"
        >
          <ChevronArrow direction="right" />
        </button>
      )}
    </div>
  );
}

function Projects() {
  const { t } = useTranslation();
  const localeLink = useLocaleLink();
  const [searchParams, setSearchParams] = useSearchParams();

  usePageMeta(t("projects.title"));

  // ইউআরএল থেকে শুরুর অবস্থা পড়া — footer/testimonial এর
  // ?category=xxx লিংক থেকে সরাসরি এলে যেন সঠিক ট্যাব সিলেক্ট থাকে
  const initialCategory = searchParams.get("category") || "all";
  const [query, setQuery] = useState(searchParams.get("q") || "");
  const [category, setCategory] = useState(
    CATEGORY_ORDER.includes(initialCategory) ? initialCategory : "all"
  );
  const [page, setPage] = useState(1);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);
  const tabsRef = useRef(null);

  // পাতা প্রথমবার আঁকা হওয়ার পর তীরচিহ্ন দরকার কিনা মাপা — না হলে
  // pill এর সারি overflow করলেও ডানের তীরটা দেখা যেত না যতক্ষণ না
  // কেউ নিজে scroll করছে
  useEffect(() => {
    updateArrows(tabsRef.current);
    const onResize = () => updateArrows(tabsRef.current);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  // ফিল্টার বদলালে ইউআরএল টাও (?q=, ?category=) সাথে সাথে আপডেট —
  // যাতে লিংক শেয়ার করা যায়। পাতা ১ এ ফেরত নেওয়াটা effect এ না
  // করে নিচের handleQueryChange/handleCategoryChange এ করা —
  // effect এর ভেতর থেকে সরাসরি setState করলে cascading render হয়
  useEffect(() => {
    const next = new URLSearchParams();
    if (query.trim()) next.set("q", query.trim());
    if (category !== "all") next.set("category", category);
    setSearchParams(next, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query, category]);

  function handleQueryChange(value) {
    setQuery(value);
    setPage(1);
  }

  function handleCategoryChange(id) {
    setCategory(id);
    setPage(1);
  }

  const counts = useMemo(() => {
    const map = { all: PROJECTS.length };
    for (const project of PROJECTS) {
      map[project.category] = (map[project.category] || 0) + 1;
    }
    return map;
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return PROJECTS.filter((project) => {
      const matchesCategory = category === "all" || project.category === category;
      if (!matchesCategory) return false;
      if (!q) return true;
      const categoryLabel = t(`projects.categories.${project.category}`).toLowerCase();
      return (
        project.name.toLowerCase().includes(q) ||
        project.city.toLowerCase().includes(q) ||
        categoryLabel.includes(q)
      );
    });
  }, [query, category, t]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, pageCount);
  const visible = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);

  // ট্যাবের সারি: বাঁ/ডান তীর দরকার আছে কিনা যাচাই
  function updateArrows(el) {
    if (!el) return;
    setCanScrollLeft(el.scrollLeft > 4);
    setCanScrollRight(el.scrollLeft + el.clientWidth < el.scrollWidth - 4);
  }

  function scrollTabsBy(amount) {
    tabsRef.current?.scrollBy({ left: amount, behavior: "smooth" });
  }

  // pagination সংখ্যার তালিকা — বেশি পাতা হলে মাঝখানে "…"
  const pageItems = useMemo(() => {
    if (pageCount <= 5) {
      return Array.from({ length: pageCount }, (_, i) => i + 1);
    }
    const items = [1];
    if (safePage > 3) items.push("ellipsis-start");
    for (let p = Math.max(2, safePage - 1); p <= Math.min(pageCount - 1, safePage + 1); p++) {
      items.push(p);
    }
    if (safePage < pageCount - 2) items.push("ellipsis-end");
    items.push(pageCount);
    return items;
  }, [pageCount, safePage]);

  return (
    <section className="section section--surface projects">
      <div className="container projects-inner">
        <header className="projects-header">
          <p className="projects-eyebrow">
            <span className="projects-eyebrow-dot" aria-hidden="true" />
            {t("projects.eyebrow")}
          </p>
          <h1 className="projects-title">{t("projects.title")}</h1>
          <p className="projects-subhead">{t("projects.subhead")}</p>
        </header>

        {/* সার্চ বার + environment dropdown — Figma "Search Bar" */}
        <div className="projects-searchbar">
          <label className="projects-search-field">
            <SearchIcon />
            <input
              type="search"
              value={query}
              onChange={(event) => handleQueryChange(event.target.value)}
              placeholder={t("projects.search.placeholder")}
              aria-label={t("projects.search.ariaLabel")}
            />
          </label>

          <label className="projects-env-select">
            <span className="sr-only">{t("projects.search.environmentAriaLabel")}</span>
            <select
              value={category}
              onChange={(event) => handleCategoryChange(event.target.value)}
              aria-label={t("projects.search.environmentAriaLabel")}
            >
              <option value="all">{t("projects.search.environmentLabel")}</option>
              {CATEGORY_ORDER.filter((id) => id !== "all").map((id) => (
                <option key={id} value={id}>
                  {t(`projects.categories.${id}`)}
                </option>
              ))}
            </select>
            <span className="projects-env-chevron" aria-hidden="true">
              <ChevronDown />
            </span>
          </label>
        </div>

        {/* category pill — Figma "Frame 419" */}
        <CategoryRow
          tabsRef={tabsRef}
          canLeft={canScrollLeft}
          canRight={canScrollRight}
          onScroll={(event) => updateArrows(event.currentTarget)}
          onLeft={() => scrollTabsBy(-240)}
          onRight={() => scrollTabsBy(240)}
        >
          {CATEGORY_ORDER.map((id) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={category === id}
              className={`projects-tab${category === id ? " is-active" : ""}`}
              onClick={() => handleCategoryChange(id)}
            >
              <span>{t(`projects.categories.${id}`)}</span>
              <span className="projects-tab-count">{counts[id] ?? 0}</span>
            </button>
          ))}
        </CategoryRow>

        {/* project grid */}
        {visible.length > 0 ? (
          <ul className="projects-grid">
            {visible.map((project) => (
              <li key={project.slug} className="projects-card">
                <div className="projects-card-media">
                  <span className="projects-card-badge">
                    {t(`projects.categories.${project.category}`)}
                  </span>
                  <img
                    src={project.image}
                    alt=""
                    width="720"
                    height="900"
                    loading="lazy"
                    decoding="async"
                  />
                </div>

                <div className="projects-card-footer">
                  <div className="projects-card-text">
                    <h2 className="projects-card-name">{project.name}</h2>
                    <p className="projects-card-city">
                      <PinIcon />
                      <span>{project.city}</span>
                    </p>
                  </div>

                  <Link
                    to={localeLink(`/projects/${project.slug}`)}
                    className="projects-card-arrow"
                    aria-label={t("projects.viewProject", { name: project.name })}
                  >
                    <ArrowUpRight />
                  </Link>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <div className="projects-empty">
            <p>{t("projects.empty")}</p>
            <p className="projects-empty-hint">{t("projects.emptyHint")}</p>
            <button
              type="button"
              className="projects-empty-clear"
              onClick={() => {
                setQuery("");
                setCategory("all");
                setPage(1);
              }}
            >
              {t("projects.clearFilters")}
            </button>
          </div>
        )}

        {/* pagination — Figma "Group 5" */}
        {pageCount > 1 && (
          <nav className="projects-pagination" aria-label="Projects pagination">
            <button
              type="button"
              className="projects-pagination-side"
              disabled={safePage === 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
            >
              <ChevronArrow direction="left" />
              <span>{t("projects.pagination.previous")}</span>
            </button>

            <ul className="projects-pagination-pages">
              {pageItems.map((item) =>
                typeof item === "number" ? (
                  <li key={item}>
                    <button
                      type="button"
                      className={`projects-pagination-page${item === safePage ? " is-active" : ""}`}
                      aria-current={item === safePage ? "page" : undefined}
                      aria-label={t("projects.pagination.pageAriaLabel", { page: item })}
                      onClick={() => setPage(item)}
                    >
                      {item}
                    </button>
                  </li>
                ) : (
                  <li key={item} className="projects-pagination-ellipsis" aria-hidden="true">
                    …
                  </li>
                )
              )}
            </ul>

            <button
              type="button"
              className="projects-pagination-side"
              disabled={safePage === pageCount}
              onClick={() => setPage((p) => Math.min(pageCount, p + 1))}
            >
              <span>{t("projects.pagination.next")}</span>
              <ChevronArrow direction="right" />
            </button>
          </nav>
        )}
      </div>
    </section>
  );
}

export default Projects;